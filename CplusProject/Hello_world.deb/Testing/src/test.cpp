#include <iostream>

int main()
{

std::cout << "hi" << std::endl;

return 0;
}
